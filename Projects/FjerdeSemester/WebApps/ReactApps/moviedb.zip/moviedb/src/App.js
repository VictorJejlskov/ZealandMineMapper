import PopularMoviesList from "./components/popularMovieList"

function App(){
    return (
        <div>
            <PopularMoviesList/>
        </div>
    )
}
export default App