import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react"

const moviesApi = createApi({
    reducerPath: "movies",
    baseQuery: fetchBaseQuery({
        baseUrl: "https://api.themoviedb.org/3/"
    }),
    endpoints(builder){
        return {
            fetchPopularMovies: builder.query({
                query: () => {
                    return {
                        url: "discover/movie",
                        params: {
                            sort_by: "popularity.desc",
                            api_key: "8e522b94f81a2dabe7fb61299c3af277"
                        },
                        method: "GET"
                    }
                }
            })
        }
    }
})

export const { useFetchPopularMoviesQuery } = moviesApi
export { moviesApi }