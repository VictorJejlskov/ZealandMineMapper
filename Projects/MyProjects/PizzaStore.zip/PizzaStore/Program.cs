﻿using System;
using System.Collections.Generic;

namespace PizzaStore
{
    class Program
    {
        static void Main(string[] args)
        {
            SandboxCode mySandboxCode = new SandboxCode();
            mySandboxCode.MyCode();
        }
    }
}
