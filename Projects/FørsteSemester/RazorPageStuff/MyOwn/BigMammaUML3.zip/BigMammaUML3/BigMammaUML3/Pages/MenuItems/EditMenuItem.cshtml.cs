using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using BigMammaUML3.Models;
using BigMammaUML3.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BigMammaUML3.Pages.MenuItems
{
    public class EditMenuItemModel : PageModel
    {
        private MenuCatalog _menuCatalog;

        public EditMenuItemModel(MenuCatalog menuCatalog)
        {
            _menuCatalog = menuCatalog;
        }

        private Pizza _pizza;
        private Beverage _beverage;
        [BindProperty] public bool SpecialCondition { get; set; }


        [Display(Name = "Nr:")]
        [Required(ErrorMessage = "Der skal indtastes et nummer")]
        [BindProperty] public int Number { get; set; }


        [Display(Name = "Navn:")]
        [Required(ErrorMessage = "Der skal indtastes et navn"), MaxLength(20)]
        [BindProperty] public string Name { get; set; }

        [Display(Name = "Beskrivelse:")]
        [Required(ErrorMessage = "Der skal indtastes en beskrivelse"), MaxLength(80)]
        [BindProperty] public string Description { get; set; }

        [Display(Name = "Pris:")]
        [Required(ErrorMessage = "Der skal indtastes en pris")]
        [BindProperty] public double Price { get; set; }
        public void OnGet(int number)
        {
            MenuItem searchedItem = _menuCatalog.Search(number);
            if (searchedItem != null)
            {
                if (searchedItem is Pizza)
                {
                    _pizza = (Pizza)searchedItem;
                }
                else if (searchedItem is Beverage)
                {
                    _beverage = (Beverage) searchedItem;
                }
            }
            else
            {
                throw new AccessViolationException();
            }
        }
    }

}
